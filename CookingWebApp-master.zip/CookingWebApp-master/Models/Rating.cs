﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CookingWebApp.Models
{
    public class Rating
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("ApplicationUser")]
        public string ApplicationUserId { get; set; }

        [ForeignKey("Recipe")]
        public int RecipeId { get; set; }

        public int RatingValue { get; set; }

       
        public ApplicationUser User { get; set; }
        public Recipe Recipe { get; set; }
    }
}

