﻿namespace CookingWebApp.Models.ModelView
{
    public class RecipeDetailsViewModel
    {
        public int RecipeId { get; set; }
        public string RecipeName { get; set; }
        public string Ingredients { get; set; }
        public string Method { get; set; }
        public string Image { get; set; }
        public double AverageRating { get; set; }
        public int RatingValue { get; set; }
        public bool UserHasRated { get; set; } 
    }

}
