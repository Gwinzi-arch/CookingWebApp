﻿
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CookingWebApp.Models.ViewModel
{
    public class RecipeViewModel
    {
        public string RecipeName { get; set; }
        public string Ingredients { get; set; }
        public string Method { get; set; }

        public string? Image { get; set; }

    }
}
