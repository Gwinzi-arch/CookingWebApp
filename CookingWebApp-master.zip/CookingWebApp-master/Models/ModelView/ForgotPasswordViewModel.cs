﻿using System.ComponentModel.DataAnnotations;

namespace CookingWebApp.Models.ViewModel
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

     

        [Required]
        [Display(Name = "Secret Answer")]
        public string SecretAnswer { get; set; }
    }
}
