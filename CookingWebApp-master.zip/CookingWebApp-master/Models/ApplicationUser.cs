﻿

using CookingWebApp.Models;
using Microsoft.AspNetCore.Identity;

public class ApplicationUser : IdentityUser
{
    public string FirstName { get; set; }
    public string LastName { get; set; }

   
    public string SecretAnswer { get; set; }



    public ICollection<Recipe> Recipes { get; set; }
    public ICollection<Rating> Ratings { get; set; }
}
