﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CookingWebApp.Models
{
    public class Recipe
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("ApplicationUser")]
        public string ApplicationUserId { get; set; }

        public string RecipeName { get; set; }
        public string Ingredients { get; set; }
        public string Method { get; set; }

        public string? Image { get; set; }

      
        public ApplicationUser User { get; set; }
        public ICollection<Rating> Ratings { get; set; }
    }
}
