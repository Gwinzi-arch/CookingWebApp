﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CookingWebApp.Data;
using CookingWebApp.Models;
using CookingWebApp.Models.ViewModel;
using Microsoft.AspNetCore.Identity;
using CookingWebApp.Models.ModelView;

namespace CookingWebApp.Controllers
{
    public class RecipesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public RecipesController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        // GET: Recipes
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Recipes.Include(r => r.User);
            return View(await applicationDbContext.ToListAsync());
        }

       
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var recipe = await _context.Recipes
                .Include(r => r.User)
                .Include(r => r.Ratings)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (recipe == null)
            {
                return NotFound();
            }

            var currentUser = await _userManager.GetUserAsync(User);
            bool userHasRated = _context.Ratings.Any(r => r.RecipeId == id && r.ApplicationUserId == currentUser.Id);

            // Calculates average rating
            double averageRating = recipe.Ratings.Average(r => r.RatingValue);

          
            var viewModel = new RecipeDetailsViewModel
            {
                RecipeName = recipe.RecipeName,
                Ingredients = recipe.Ingredients,
                Method = recipe.Method,
                Image = recipe.Image,
                AverageRating = averageRating,
                RecipeId = (int)id,
                UserHasRated = userHasRated,
            };

            return View(viewModel);
        }


        // GET: Recipes/Create
        public IActionResult Create()
        {
            ViewData["ApplicationUserId"] = new SelectList(_context.Users, "Id", "Id");
            return View();
        }

        // POST: Recipes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RecipeName,Ingredients,Method,Image")] RecipeViewModel recipeViewModel)
        {
            if (ModelState.IsValid)
            {
                // Get the current user 
                var user = await _userManager.GetUserAsync(User);

                if (user == null)
                {
                    // Log or handle the case where the user is null
                    return RedirectToAction(nameof(Index)); 
                }

                // Create a new Recipe
                var recipe = new Recipe
                {
                    ApplicationUserId = user.Id,
                    RecipeName = recipeViewModel.RecipeName,
                    Ingredients = recipeViewModel.Ingredients,
                    Method = recipeViewModel.Method,
                    Image = recipeViewModel.Image
                };

                _context.Add(recipe);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            return View(recipeViewModel);
        }

     

      

        // GET: Recipes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Recipes == null)
            {
                return NotFound();
            }

            var recipe = await _context.Recipes
                .Include(r => r.User)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (recipe == null)
            {
                return NotFound();
            }

            return View(recipe);
        }

        // POST: Recipes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Recipes == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Recipes'  is null.");
            }
            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe != null)
            {
                _context.Recipes.Remove(recipe);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RecipeExists(int id)
        {
          return (_context.Recipes?.Any(e => e.Id == id)).GetValueOrDefault();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitRate(int recipeId, int ratingValue)
        {
            var user = await _userManager.GetUserAsync(User);

            // Check if the recipe exists
            var recipe = await _context.Recipes.FindAsync(recipeId);
            if (recipe == null)
            {
                // Handle the situation when the recipe doesn't exist
                // For example, redirect to an error page or show an error message
                return NotFound("Recipe not found");
            }

            // Check if the user has already rated the recipe
            if (_context.Ratings.Any(r => r.RecipeId == recipeId && r.ApplicationUserId == user.Id))
            {
                return RedirectToAction(nameof(Details), new { id = recipeId });
            }

            // Create a new rating
            var newRating = new Rating
            {
                RecipeId = recipeId,
                ApplicationUserId = user.Id,
                RatingValue = ratingValue
            };

            // Add the new rating to the database
            _context.Ratings.Add(newRating);
            await _context.SaveChangesAsync();

            // Redirect back to the recipe details page
            return RedirectToAction(nameof(Details), new { id = recipeId });
        }






    }
}
